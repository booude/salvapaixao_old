# Salva Compra App

## Uso

    Relação de produtos para uso interno da empresa NTP Engenharia.
    Gerencia preços, custos tributários e organiza orçamentos.

### PhoneGap CLI

    $ phonegap create my-app --template blank

### Desktop

In your browser, open the file:

    /www/index.html
